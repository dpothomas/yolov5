"""Top-level package for mojo shared AI utils."""

__author__ = """mojo AI"""
__email__ = "daniel.rodrigues@mojofertility.co, robin@mojofertility.co"
__version__ = "1.0.0"

from dotenv import find_dotenv, load_dotenv

from . import misc_utils

# Environment variable injection from .env file
load_dotenv(find_dotenv())

# Loading the mojo matplotlib theme in case it's needed
misc_utils.load_mojo_mpl_theme()
