import collections
from typing import List, Tuple
import os
import matplotlib
import numpy as np
import plotly.graph_objects as go

from pathlib import Path
import aisa_utils.constants as C
import cv2


def plot_object_count_difference_ridgeline(
    ground_truths: List[np.ndarray], preds: List[np.ndarray]
) -> Tuple[go.Figure, float]:
    """
    Generate a ridgeline plot showing the difference between detected objects and ground truth objects,
    accumulated over entire dataset.
    @param ground_truths: a list of ground truths in yolov5 format
    @param preds: a list of prediction in yolov5 format
    @return: plotly figure object and suggested threshold based on peak height/curve area ratio
    """
    n_gts = [len(gt) for gt in ground_truths]
    scores = get_scores_from_preds(preds)

    # reversing order to make plotly plots put highest threshold on the bottom of the figure
    thresholds = C.DL_TEST_THRESHOLDS[::-1]

    diff_at_threshold = []
    for threshold in thresholds:
        differences = []
        for (image_scores, n_gt) in zip(scores, n_gts):
            diff = image_scores[image_scores > threshold].size - n_gt
            differences.append(diff)
        diff_at_threshold.append(differences)

    cmap = matplotlib.cm.get_cmap("summer_r")
    ratios = []
    abs_ratios = []

    # calculate curve goodness ratios
    for data_line in diff_at_threshold:
        (_, peak_height), *_ = collections.Counter(data_line).most_common(1)
        (_, abs_peak_height), *_ = collections.Counter(
            np.absolute(data_line)
        ).most_common(1)
        curve_area = len(data_line)
        ratio = (peak_height / curve_area) ** 2
        abs_ratio = (abs_peak_height / curve_area) ** 2

        ratios.append(ratio)
        abs_ratios.append(abs_ratio)

    # normalize the ratios [0..1]
    ratios = np.array(ratios) / max(ratios)
    abs_ratios = np.array(abs_ratios) / max(abs_ratios)
    suggested_threshold = thresholds[ratios.argmax()]
    width = 4
    fig = go.Figure()

    for data_line, threshold, ratio, abs_ratio in zip(
        diff_at_threshold, thresholds, ratios, abs_ratios
    ):
        # get color based on ratio value
        line_color = "rgb({:1.5f},{:1.5f},{:1.5f})".format(*cmap(ratio))

        fig.add_trace(
            go.Violin(
                x=np.array(data_line),
                line_color=line_color,
                scalegroup="mygroup",
                name=f"threshold {threshold:1.2f}",
                width=width * ratio,
            )
        )

        fig.add_trace(
            go.Violin(
                x=abs(np.array(data_line)),
                line_color=line_color,
                scalegroup="othergroup",
                name=f"threshold {threshold:1.2f}",
                visible=False,
                width=width * abs_ratio,
            )
        )

    fig.update_traces(
        orientation="h",
        side="positive",
        points=False,
        scalemode="count",
        spanmode="hard",
        #     spanmode="manual",
        #     span=[-50,50],
    )
    fig.update_layout(
        xaxis_showgrid=True,
        xaxis_zeroline=True,
        xaxis_title="object count difference (detected - ground truth)",
    )

    regular_diff_display = [True, False] * len(thresholds)
    absolute_diff_display = regular_diff_display[::-1]

    # define button activity - switching display
    fig.update_layout(
        updatemenus=[
            dict(
                buttons=list(
                    [
                        dict(
                            label="False",
                            method="update",
                            args=[{"visible": regular_diff_display}],
                        ),
                        dict(
                            label="True",
                            method="update",
                            args=[{"visible": absolute_diff_display}],
                        ),
                    ]
                ),
                type="buttons",
                direction="right",
                pad={"r": 0, "t": 0},
                showactive=True,
                x=1.1,
                xanchor="left",
                y=0,
                yanchor="top",
            ),
        ]
    )
    # define button description box
    fig.update_layout(
        annotations=[
            dict(
                text="Absolute<br>Diff",
                x=1.1,
                xref="paper",
                y=-0.1,
                yref="paper",
                showarrow=False,
            ),
            dict(
                text="Colors reflect peak height/curve area ratio",
                x=1.2,
                xref="paper",
                y=1.1,
                yref="paper",
                showarrow=False,
            ),
        ]
    )
    return fig, suggested_threshold


def get_scores_from_preds(preds):
    return [pred[:, 4] for pred in preds]


def plot_detections_jitter(preds: List[np.ndarray]) -> go.Figure:
    """
    Generate a plot showing detections jitter over time (frame number). Assuming that the input preds
    are coming from an inference run on a video and are sequential.
    @param preds: a list of prediction in yolov5 format
    @return: plotly figure object
    """
    scores = get_scores_from_preds(preds)

    objects = dict()
    for threshold in C.DL_TEST_THRESHOLDS:
        objects_per_frame = []
        for image_scores in scores:
            n_objects = image_scores[image_scores > threshold].size
            objects_per_frame.append(n_objects)
        objects[f"{threshold:1.2f}"] = objects_per_frame

    fig = go.Figure()
    for key in objects.keys():
        fig.add_scatter(y=objects[key], mode="lines", name=key)

    fig.update_layout(
        xaxis_title="Frame",
        yaxis_title="Detected objects count",
        legend_title="Threshold values",
    )

    return fig


def viz_frame(frame, pred):
    rgb_frame = get_rgb_image(frame)
    for p in pred:
        center = [int(p[0]*frame.shape[1]), int(p[1]*frame.shape[0])]

        color = C.SPERM_COLOR
        text_color = C.SPERM_COLOR
        cv2.line(
            rgb_frame,
            (center[0] - 3, center[1] - 3),
            (center[0] + 3, center[1] + 3),
            color,
            2,
        )
        cv2.line(
            rgb_frame,
            (center[0] + 3, center[1] - 3),
            (center[0] - 3, center[1] + 3),
            color,
            2,
        )
        if rgb_frame.shape[0] > 1000:
            text_size = 2
        else:
            text_size = 1
        cv2.putText(
            rgb_frame,
            f"{p[4]:.2f}",
            (center[0], center[1] - 4),
            cv2.FONT_HERSHEY_SIMPLEX,
            text_size,
            text_color,
            text_size,
            cv2.LINE_AA,
        )
    return rgb_frame

def get_rgb_image(image):
    if isinstance(image, list):
        image = np.array(image)
    if len(image.shape) == 3 and image.shape[2] == 3:
        rgb_image = np.copy(image)
    elif len(image.shape) == 3 and image.shape[2] == 1:
        rgb_image = np.dstack([image[:, :, 0]] * 3)
    elif len(image.shape) == 2:
        rgb_image = np.dstack([image] * 3)
    else:
        raise Exception(f"Cannot convert image with shape: {image.shape} to rgb.")
    return rgb_image


def make_video_results(video_path, video_prediction_function):
    frames = load_frames(video_path, resize_factor=2)
    preds = video_prediction_function(frames)
    output_filename = Path(f"outputs/{video_path.stem}.mp4").resolve()
    output_filename.parent.mkdir(exist_ok=True, parents=True)
    if os.name == 'nt':
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    else:
        fourcc = cv2.VideoWriter_fourcc(*'VP09')
    writer = cv2.VideoWriter(
        str(output_filename),
        fourcc,
        60,
        (frames[0].shape[1], frames[0].shape[0]),
        True,
    )
    print(f"Saving video results to {output_filename}")
    for frame, pred in zip(frames, preds):
        writer.write(viz_frame(frame, pred))
    writer.release()

    fig = plot_detections_jitter(preds)

    return output_filename, fig


def load_frames(frame_location, max_frames_to_load=1000, resize_factor=1):
    """Analyze a sequence of videos. Each video is analyzed individually
        before summarizing the results in a patient_results.json

        Parameters
        ----------
        frame_location : str
            Location of frames (folder of images or video)
        max_frames_to_load : int, optional
            Max number of frames to load from location.
            Can be used to reduce memory usage.
            (default 1000)

        Returns
        ----------
        frames : array
            Array containing all the frames (n_frames, h, w)
        """
    frames = []
    # Convert Path to str because opencv is stupid and only accepts str
    if isinstance(frame_location, Path):
        frame_location = str(frame_location)
    # If only one string then assume video:
    if type(frame_location) in [str, np.str]:
        cap = cv2.VideoCapture(frame_location)
        while cap.isOpened():
            ret, frame = cap.read()
            if ret and len(frames) < max_frames_to_load:
                frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
            else:
                break
        cap.release()
    else:
        for image_path in frame_location:
            frames.append(cv2.imread(image_path, 0))

    if resize_factor != 1:
        frames = np.array(
            [
                cv2.resize(im, None, fx=1 / resize_factor, fy=1 / resize_factor)
                for im in frames
            ]
        )
    return np.array(frames)


if __name__ == "__main__":
    video_path = Path(r"D:\Nanovare\data\karolinska\capture_MAST_data\2020_05_27\tp49\cover1_7.avi")

    def video_prediction_function(frames):
        preds = [[[0.1, 0.5, 0.01, 0.01, 0.1, 1],
                 [0.5, 0.5, 0.01, 0.01, 0.5, 1],
                 [0.9, 0.5, 0.01, 0.01, 0.9, 1],]]*len(frames)
        return np.array(preds)
    make_video_results(video_path, video_prediction_function)
