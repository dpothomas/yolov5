import json
import pickle
import random
import shutil
from pathlib import Path

import cv2
import pandas as pd
import tqdm
import yaml
from PIL import Image
from sklearn import model_selection

import aisa_utils.constants

# Methods


def filter_image_path_list(image_path_list):
    discard_path_list = []

    # Getting image dimensions (using PIL to avoid loading into memory)
    # This assumes all images are the same size - a fair assumption
    im = Image.open(image_path_list[0])
    width, height = im.size
    del im

    for frame_path in image_path_list:
        annotation_path = frame_path.parents[1] / "ann" / (frame_path.name + ".json")
        if not annotation_path.is_file():
            annotation_data = {
                "description": "",
                "tags": [],
                "size": {"height": height, "width": width},
                "objects": [],
            }

            with annotation_path.open("w") as f:
                json.dump(annotation_data, f)

        with annotation_path.open("r") as annotation_file:
            annotation_data = json.load(annotation_file)

        discard = False
        # Remove images with no objects (to remove images not tagged yet)
        if len(annotation_data["objects"]) == 0:
            discard = True
        tags = list(map(lambda x: x["name"], annotation_data["tags"]))

        # Remove images with/without objects (but tagged as to be ignored)
        if "To ignore" in tags:
            discard = True

        if discard:
            discard_path_list.append(frame_path)

    return list(set(image_path_list) - set(discard_path_list))


def create_train_val_split(image_stem_list, strategy, train_test_split_dict_path=None):

    # Split by patient randomly or just split randomly
    if strategy == aisa_utils.constants.SplittingStrategy.none:
        train_stem, val_stem = [], []
    elif strategy == aisa_utils.constants.SplittingStrategy.patient:
        patient_id_list = pd.unique(
            list(map(lambda x: x.split("_")[3], image_stem_list))
        )
        train_patient_id, val_patient_id = model_selection.train_test_split(
            patient_id_list, test_size=0.25, shuffle=True, random_state=42
        )
        train_stem = [x for x in image_stem_list if x.split("_")[3] in train_patient_id]
        val_stem = [x for x in image_stem_list if x.split("_")[3] in val_patient_id]
        random.shuffle(train_stem)
    elif strategy == aisa_utils.constants.SplittingStrategy.random:
        train_stem, val_stem = model_selection.train_test_split(
            image_stem_list, test_size=0.25, shuffle=True, random_state=42
        )
    elif strategy == aisa_utils.constants.SplittingStrategy.load:
        is_kings_v2 = image_stem_list[0].endswith("-1")
        if not train_test_split_dict_path.is_file():
            raise Exception(
                f"{train_test_split_dict_path} does not exist, cannot load train_test_split_dict."
            )
        with train_test_split_dict_path.open("rb") as f:
            train_test_split_dict = pickle.load(f)
        train_stem = train_test_split_dict["train_stem"]
        val_stem = train_test_split_dict["val_stem"]
        if not is_kings_v2:
            train_stem = [_[:-2] for _ in train_stem]
            val_stem = [_[:-2] for _ in val_stem]
    else:
        raise Exception(f"Split strategy unknown: {strategy}")

    if train_stem:
        assert set(val_stem + train_stem).issubset(image_stem_list)
    return train_stem, val_stem


def convert_supervisely_to_yolo(
    data_dir,
    yolo_data_dir,
    color,
    filter_annotation=True,
    strategy=aisa_utils.constants.SplittingStrategy.random,
    overwrite=False,
    save_train_test_split=False,
):
    image_path_list = list(data_dir.glob("**/*.png"))
    dataset_length_supervisely = len(image_path_list)

    if filter_annotation:

        image_path_list = filter_image_path_list(image_path_list)
    print(
        f"\nKeeping {len(image_path_list)} annotated images out of a total of "
        f"{dataset_length_supervisely} Supervisely images...\n"
    )
    image_stem_list = list(map(lambda x: x.stem, image_path_list))

    if yolo_data_dir.exists():
        if overwrite:
            print(f"WARNING: Overwriting folder: {yolo_data_dir}")
            shutil.rmtree(yolo_data_dir)
        else:
            raise FileExistsError(
                f"The dataset {yolo_data_dir}"
                f" already exists. Cannot override, exiting..."
            )
    if strategy == aisa_utils.constants.SplittingStrategy.load:
        train_test_split_dict_path = data_dir / "train_test_split_dict.pkl"
    else:
        train_test_split_dict_path = None
    train_stem, val_stem = create_train_val_split(
        image_stem_list, strategy, train_test_split_dict_path=train_test_split_dict_path
    )
    print(f"Training images: {len(train_stem)}")
    print(f"Validation images: {len(val_stem)}")
    print(f"Test images: {len(image_path_list)-len(val_stem)-len(train_stem)}")

    for frame_path in tqdm.tqdm(image_path_list, "Converting to YOLO format"):
        if color == "bgr":
            image = cv2.imread(str(frame_path), 1)
        elif color == "green":
            image = cv2.imread(str(frame_path), 1)[:, :, 1]
        elif color == "gray":
            image = cv2.imread(str(frame_path), 0)
        else:
            raise ValueError("Wrong color")

        # Selecting the target location (train/val/test)
        if not train_stem:
            folder = "test"
        elif frame_path.stem in train_stem:
            folder = "train"
        elif frame_path.stem in val_stem:
            folder = "val"

        # Creating the folder structure
        yolo_image_path = yolo_data_dir / "images" / folder / f"{frame_path.stem}.jpg"
        yolo_annotation_path = (
            yolo_data_dir / "labels" / folder / f"{frame_path.stem}.txt"
        )
        yolo_image_path.parent.mkdir(parents=True, exist_ok=True)
        yolo_annotation_path.parent.mkdir(parents=True, exist_ok=True)

        annotation_path = frame_path.parents[1] / "ann" / (frame_path.name + ".json")

        # Saving
        with annotation_path.open("r") as annotation_file:
            annotation_data = json.load(annotation_file)

        convert_supervisely_to_yolo_image(
            image, yolo_image_path, annotation_data, yolo_annotation_path
        )

    # Create YAML file for YOLOv5
    class_names = [""] * len(aisa_utils.constants.ANNOTATION_CLASSES_TO_ID)
    for class_name in aisa_utils.constants.ANNOTATION_CLASSES_TO_ID:
        class_names[
            aisa_utils.constants.ANNOTATION_CLASSES_TO_ID[class_name]
        ] = class_name

    data = dict(
        path=str(yolo_data_dir),
        train="images/train" if train_stem else "",
        val="images/val" if train_stem else "",
        test="images/test" if not train_stem else "",
        nc=len(class_names),
        names=class_names,
    )

    yaml_file_path = yolo_data_dir / "data.yaml"
    with yaml_file_path.open("w") as file:
        yaml.dump(data, file)

    if save_train_test_split:
        test_split_dict_path = yolo_data_dir / "train_test_split_dict.pkl"
        test_split_dict = {"train_stem": train_stem, "val_stem": val_stem}
        with test_split_dict_path.open("wb") as file:
            pickle.dump(test_split_dict, file)
    return yaml_file_path


def convert_supervisely_to_yolo_image(
    image, yolo_image_path, annotation_data, yolo_annotation_path, w=80
):
    cv2.imwrite(yolo_image_path.as_posix(), image)
    im_height, im_width = image.shape[:2]
    with yolo_annotation_path.open("w") as f:
        for obj in annotation_data["objects"]:
            if (
                obj["classTitle"]
                not in aisa_utils.constants.SUPERVISELY_CLASS_NAME_MAPPING
            ):
                continue
            class_id = aisa_utils.constants.ANNOTATION_CLASSES_TO_ID[
                aisa_utils.constants.SUPERVISELY_CLASS_NAME_MAPPING[obj["classTitle"]]
            ]
            x = obj["points"]["exterior"][0][0]
            y = obj["points"]["exterior"][0][1]

            # Annotations at the edge not handled by yolo format
            if x == 0:
                x = 1
            if y == 0:
                y = 1
            if x == im_width:
                x = im_width - 1
            if y == im_height:
                y = im_height - 1

            bbox = [x, y, w, w]

            # Single class training
            if class_id == 0:
                f.write(
                    f"{class_id} "
                    f"{bbox[0]/im_width:.6f} "
                    f"{bbox[1]/im_height:.6f} "
                    f"{bbox[2]/im_width:.6f} "
                    f"{bbox[3]/im_height:.6f}\n"
                )
