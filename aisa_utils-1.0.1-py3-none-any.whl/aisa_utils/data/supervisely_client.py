import importlib.resources as pkg_resources
import os
from pathlib import Path

import typer
import yaml

import aisa_utils.constants
import aisa_utils.data.nanovare_yolo as yolo
import aisa_utils.data.supervisely_api_wrapper as sly


# Helper functions
def _load_dataset_from_resources_or_file(dataset_tag: str):
    """Loads and returns the fields of the YAML file with dataset details (project ID and names
    of specific datasets to download), either using a supplied file or by loading one of the
    built-in ones (if the dataset tag matches one)."""

    name_tag = Path(dataset_tag).stem.lower().strip().replace("-", "").replace("_", "")

    with pkg_resources.path("aisa_utils", "resources") as p:
        resources_folder = p

    available_datasets = [
        f.stem for f in resources_folder.iterdir() if str(f).endswith(".yaml")
    ]

    if name_tag in available_datasets:
        print(f"Found built-in dataset {name_tag}, using it...")
        dataset_file = resources_folder / (name_tag + ".yaml")
        with open(dataset_file, "r") as fr:
            data = yaml.load(fr, Loader=yaml.FullLoader)
            project_id = data["project_id"]
            datasets = data["datasets_names"]

            # If no datasets are specified, download all
            if not datasets:
                datasets = "all"

            try:
                patients = data["patients"]
            except KeyError:
                patients = None

    # In case it's not one of the default ones, load it directly from the supplied file
    else:
        print(f"\nLoading dataset details from file {dataset_tag}...")
        with open(dataset_tag, "r") as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
            project_id = data["project_id"]
            datasets = data["datasets_names"]

            # If no datasets are specified, download all
            if not datasets:
                datasets = "all"

            try:
                patients = data["patients"]
            except KeyError:
                patients = None

    return project_id, name_tag, datasets, patients


def sanity_check_dataset(input_dataset: Path):
    """Quickly checks if the supplied dataset folder has the expected format before YOLO conversion."""

    ann_folder = input_dataset / "ann"
    img_folder = input_dataset / "img"
    meta_file = input_dataset / "meta.json"

    try:
        assert ann_folder.is_dir()
        assert img_folder.is_dir()
        assert meta_file.is_file()

        # Checking if the folders are not empty
        n_images = sum(1 for _ in img_folder.glob("*"))
        n_annotations = sum(1 for _ in ann_folder.glob("*"))

        assert n_images > 0
        assert n_images == n_annotations
    except Exception:
        raise AssertionError(
            "The supplied folder does not seem to have a valid dataset"
        )

    return True


# ---
# CLI app
app = typer.Typer(add_completion=True)


# Commands
@app.command()
def download(
    dataset_tag: str = typer.Argument(
        ...,
        help="Path to the YAML file with the information regarding the project \
        to download (must have fields project_id (int) and datasets_names (list of str)) OR \
        name of one of the default datasets available on the package.",
    ),
    output_folder: Path = typer.Argument(
        Path("./"),
        help="Path to the folder where the project will be downloaded to. If it doesn't exist, it will be created.",
    ),
):
    """Download datasets from Supervisely"""

    # First let's load the data (either from the supplied YAML or from the built-in datasets)
    project_id, dataset_tag, datasets, patients = _load_dataset_from_resources_or_file(
        dataset_tag
    )

    # Some preparations
    remote_dataset_name_id = dict(
        map(
            lambda x: (x.id, x.name),
            sly.Api().dataset.get_list(project_id),
        )
    )

    # Getting the IDs of the desired datasets
    if datasets == "all":
        dataset_filter_id = None
    else:
        dataset_filter_id = list(
            dict(filter(lambda x: x[1] in datasets, remote_dataset_name_id.items()))
        )

    print(
        f"\nDownloading data {datasets} from project {project_id} to the folder {output_folder} ...\n"
    )

    output_path = sly.init_supervisely_dataset(
        output_folder,
        project_id,
        Path(output_folder) / dataset_tag,
        dataset_filter_id=dataset_filter_id,
        patients_filter_id=patients,
    )

    print(f"Requested datasets downloaded to {output_path} ✓")


@app.command()
def upload(
    input_folder: Path = typer.Argument(
        ...,
        help="Path to the folder where the project will be downloaded to. If it doesn't exist, it will be created.",
    ),
    project_id: int = typer.Argument(
        ...,
        help="Supervisely id linked zith the project to uplaod to.",
    ),
    dataset_name: str = typer.Option(
        None,
        help="Dataset name to use on Supervisely (if not specified defaults to root local folder name)",
    ),
):
    supervisely_api = sly.Api(
        token=os.environ.get("SUPERVISELY_API_KEY"),
        server_address="https://app.supervise.ly/",
    )
    supervisely_api.upload_yolo_data(
        input_folder, project_id, dataset_name=dataset_name
    )


@app.command()
def convert2yolo(
    dataset_folder: Path = typer.Argument(
        ...,
        help="Path to the folder containing the Supervisely dataset downloaded through aisa-data ",
    ),
    output_folder: Path = typer.Argument(
        None,
        help="Path where to save the converted dataset. If not specified, it will be saved in the dataset's location, \
        in a folder called yolo.",
    ),
    img_color: aisa_utils.constants.ImageColors = typer.Option(
        aisa_utils.constants.ImageColors.gray,
        help="Type of image color output: grayscale, BGR or green",
    ),
    split_strategy: aisa_utils.constants.SplittingStrategy = typer.Option(
        aisa_utils.constants.SplittingStrategy.random,
        help="Whether to split the data into training and validation sets (either totally random or patient-based random) \
            or not split at all.",
    ),
    overwrite: bool = typer.Option(
        False, help="Overwrite the yolo folder if it already exists."
    ),
):
    """Converts an already downloaded Supervisely dataset to the YOLO v5 format."""

    # Quickly sanity check the supplied input path
    sanity_check_dataset(dataset_folder)

    if output_folder is None:
        output_path = dataset_folder / "yolo"
    else:
        output_path = Path(output_folder)

    print(
        f"\nConverting dataset in {dataset_folder} to the YOLO format, saving it at {output_path}..."
    )

    _ = yolo.convert_supervisely_to_yolo(
        data_dir=dataset_folder,
        yolo_data_dir=output_path,
        color=img_color.value,
        filter_annotation=True,
        strategy=split_strategy.value,
        overwrite=overwrite,
    )

    print(f"\nConversion finished. Dataset available at {output_path} ✔")
