import json
import os
import shutil
from pathlib import Path

import cv2
import supervisely_lib as sly
import tqdm


def get_yolo_labels(im_path):
    labels_path = im_path.parents[1] / "labels" / f"{im_path.stem}.txt"
    with labels_path.open("r") as f:
        lines = f.readlines()
        labels = []
        for line in lines:
            line = line.rstrip().split()
            labels.append([int(line[0])] + list(map(float, line[1:])))
    return labels


# Helper classes
class Api(sly.Api):
    def __init__(
        self,
        server_address="https://app.supervise.ly/",
        token=os.environ.get("SUPERVISELY_API_KEY"),
        root_dir=".",
    ):

        """High-level custom functionnalities on top of the Supervisely SDK

        See https://api.docs.supervise.ly/ to see every available tasks exposed by
        the official API and the official SDK doc https://sdk.docs.supervise.ly/

        Args:
            server_address : str
                Address of the Supervisely server
            token : str
                Supervisely API key for login
            root_dir : str or Path
                Local root directory to download the supervisely datasets


        """
        super(Api, self).__init__(server_address, token)
        self.root_dir = root_dir

    def upload_mast_annotation_data(
        self, root_folder, project_id, video_names_to_exclude=["results"]
    ):
        for video_path in tqdm.tqdm(
            list(Path(root_folder).resolve().glob("**/*.avi")),
            f"Upload " f"from {root_folder} to project {project_id}",
            leave=True,
            unit="im",
        ):
            # Exclude results video:
            if video_path.stem in video_names_to_exclude:
                continue

            try:
                im = cv2.VideoCapture(video_path.as_posix()).read()[1]
            except Exception as e:
                print(f"Could not load {video_path}: {e}")
                continue

            dataset_name = video_path.parents[1].name
            dataset = self.dataset.get_or_create(project_id, dataset_name)

            uploaded_im_name = f"{video_path.parents[0].name}_{video_path.stem}.png"
            if not self.image.exists(dataset.id, uploaded_im_name):
                self.image.upload_np(dataset.id, uploaded_im_name, im)

    def upload_yolo_data(
        self, root_folder, project_id, upload_greyscale=False, dataset_name=None
    ):
        project_info = self.project.get_info_by_id(project_id)

        if dataset_name is None:
            dataset_name = root_folder.name
        dataset = self.dataset.get_or_create(project_id, dataset_name)
        print(
            f"Uploading {root_folder} to project {project_info.name} ({project_id}), dataset {dataset.name} ({dataset.id})."
        )

        # Check that the two classes Low Conf Sperm and High Conf Sperm exist.
        meta_json = self.project.get_meta(project_id)
        meta = sly.ProjectMeta.from_json(meta_json)

        if meta.get_obj_class("Low Conf Sperm") is None:
            meta = meta.add_obj_class(
                sly.ObjClass(
                    name="Low Conf Sperm",
                    geometry_type=sly.Point,
                    color=[255, 10, 10],
                )
            )
        if meta.get_obj_class("High Conf Sperm") is None:
            meta = meta.add_obj_class(
                sly.ObjClass(
                    name="High Conf Sperm",
                    geometry_type=sly.Point,
                    color=[10, 255, 10],
                )
            )
        low_conf_sperm_class = meta.get_obj_class("Low Conf Sperm")
        high_conf_sperm_class = meta.get_obj_class("High Conf Sperm")
        self.project.update_meta(project_id, meta.to_json())

        for image_path in tqdm.tqdm(
            list(Path(root_folder).resolve().glob("images/*.png")),
            f"Upload " f"from {root_folder} to project {project_id}",
            leave=True,
            unit="im",
        ):
            if upload_greyscale:
                im = cv2.imread(str(image_path), 0)
            else:
                im = cv2.imread(str(image_path), 1)

            ann = sly.Annotation(im.shape[:2])
            yolo_labels = get_yolo_labels(image_path)
            for yolo_label in yolo_labels:
                if yolo_label[0] == 0 and yolo_label[-1] >= 0.8:
                    supervisely_class = high_conf_sperm_class
                elif yolo_label[0] == 0 and yolo_label[-1] < 0.8:
                    supervisely_class = low_conf_sperm_class
                else:
                    raise Exception(
                        f"Cannot infer supervisely class from "
                        f"yolo annotation: {yolo_label}"
                    )
                label = sly.Label(
                    sly.Point(
                        int(yolo_label[2] * im.shape[0]),
                        int(yolo_label[1] * im.shape[1]),
                    ),
                    supervisely_class,
                )
                ann = ann.add_label(label)
            assert len(ann.labels) == len(yolo_labels)

            uploaded_im_name = f"{image_path.name}"

            if not self.image.exists(dataset.id, uploaded_im_name):
                _ = self.image.upload_np(dataset.id, uploaded_im_name, im)

            image_info = self.image.get_info_by_name(dataset.id, uploaded_im_name)
            self.annotation.upload_ann(image_info.id, ann)

    def download_merge_project(self, project_id, dataset_filter_id=None):
        self.download_project(project_id, dataset_filter_id)
        self.merge_project(project_id, dataset_filter_id)

    def download_project(
        self,
        project_id,
        download_dir,
        dataset_filter_id=None,
        patients_filter_id=None,
        update=False,
        check=True,
    ):
        dataset_info_list = filter(
            lambda x: dataset_filter_id is None or x.id in dataset_filter_id,
            self.dataset.get_list(project_id),
        )
        for dataset_info in dataset_info_list:
            if update or (
                check and not self.check_dataset_match_directory(dataset_info.id)
            ):
                self.download_dataset(
                    dataset_info.id,
                    download_dir,
                    patients_filter_id=patients_filter_id,
                    replace=False,
                )

    def get_project_dir(self, project_id, dir_name):
        return self._get_project_dir(project_id) / dir_name

    def merge_project(
        self, project_id, dataset_filter_id=None, update=False, dir_name="all"
    ):
        if dir_name == "":
            raise ValueError("dir_name can not be empty")
        dataset_info_list = filter(
            lambda x: dataset_filter_id is None or x.id in dataset_filter_id,
            self.dataset.get_list(project_id),
        )
        project_dir = self._get_project_dir(project_id) / dir_name
        if update:
            self._remove_dir(project_dir)
        image_dir = self._check_dir(project_dir / "img")
        annotation_dir = self._check_dir(project_dir / "ann")

        for dataset_info in dataset_info_list:
            dataset_dir = self._get_dataset_dir(dataset_info.id)
            image_path_list = list(dataset_dir.glob("*/*.png"))
            annotation_path_list = list(dataset_dir.glob("*/*.json"))
            for image_path, annotation_path in zip(
                image_path_list, annotation_path_list
            ):
                shutil.copy(
                    image_path,
                    image_dir / f"{dataset_dir.name}_{image_path.name}",
                )
                shutil.copy(
                    annotation_path,
                    annotation_dir / f"{dataset_dir.name}_{annotation_path.name}",
                )

        json.dump(
            self.project.get_meta(project_id), fp=open(project_dir / "meta.json", "w")
        )
        return image_dir

    def download_project_metadata(self, project_id: int, output_folder: Path):

        output_filepath = output_folder / "meta.json"
        with output_filepath.open("w") as f:
            json.dump(self.project.get_meta(project_id), f)

    def download_dataset(
        self, dataset_id, download_dir, patients_filter_id=None, replace=True
    ):
        if replace:
            self._remove_dir(download_dir)
        image_list = self.image.get_list(dataset_id)

        # Filtering for specific patients
        if patients_filter_id is not None:
            image_list = list(
                filter(
                    lambda x: x.name[: x.name.find("_")] in patients_filter_id,
                    image_list,
                )
            )

        image_dir = self._check_dir(download_dir / "img")
        annotation_dir = self._check_dir(download_dir / "ann")

        for image_info in tqdm.tqdm(
            image_list,
            f"Downloading "
            f"dataset with ID {dataset_id} "
            f"to directory '{download_dir.resolve()}'",
            leave=False,
            unit="im",
        ):
            image_path = image_dir / image_info.name
            annotation_path = annotation_dir / (image_info.name + ".json")

            self.image.download_path(image_info.id, image_path)
            json.dump(
                self.annotation.download(image_info.id).annotation,
                fp=open(annotation_path, "w"),
            )

        return download_dir

    def check_dataset_match_directory(self, dataset_id):
        dataset_dir = self._get_dataset_dir(dataset_id)
        for image_info, annotation_info in zip(
            self.image.get_list(dataset_id), self.annotation.get_list(dataset_id)
        ):
            if not (
                image_info.name in map(lambda x: x.name, dataset_dir.glob("*/*.png"))
            ):
                return False
            if not (
                annotation_info.image_name + ".json"
                in map(lambda x: x.name, dataset_dir.glob("*/*.json"))
            ):
                return False
        tqdm.tqdm.write(f"Check dataset with ID {dataset_id} OK")
        return True

    @staticmethod
    def _check_dir(directory):
        Path(directory).mkdir(parents=True, exist_ok=True)
        return Path(directory)

    def _remove_dir(self, directory):
        self._check_dir(directory)
        shutil.rmtree(directory.resolve().as_posix())

    def _get_remote_project_dir(self, project_id):
        project_info = self.project.get_info_by_id(project_id)
        return project_info.name

    def _get_remote_dataset_dir(self, dataset_id):
        dataset_info = self.dataset.get_info_by_id(dataset_id)
        project_info = self.project.get_info_by_id(dataset_info.project_id)
        return self._get_remote_project_dir(project_info.id) / dataset_info.name

    def _get_project_dir(self, project_id):
        return self._check_dir(
            Path(self.root_dir) / self._get_remote_project_dir(project_id)
        )

    def _get_dataset_dir(self, dataset_id):
        return self._check_dir(Path(self.root_dir))


# Helper functions
def init_supervisely_dataset(
    root_dir,
    project_id,
    project_download_dir,
    dataset_filter_id=None,
    patients_filter_id=None,
):
    api = Api(token=os.environ.get("SUPERVISELY_API_KEY"), root_dir=root_dir)
    api.download_project(
        project_id,
        project_download_dir,
        dataset_filter_id=dataset_filter_id,
        patients_filter_id=patients_filter_id,
        update=False,
        check=True,
    )

    # Downloading a JSON file with meta information about the project
    api.download_project_metadata(project_id, project_download_dir)

    return project_download_dir


def get_supervisely_data_dir(dir_name, root_dir, project_id):
    api = Api(token=os.environ.get("SUPERVISELY_API_KEY"), root_dir=root_dir)
    return api.get_project_dir(project_id=project_id, dir_name=dir_name)


if __name__ == "__main__":
    im_path = Path(r"D:\Nanovare\data\yolo-testV3\images\lb002_cover0_0.png")
    get_yolo_labels(im_path)
