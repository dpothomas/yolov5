"""Base module."""

import shutil
from pathlib import Path

import matplotlib as mpl


def load_mojo_mpl_theme():
    """Copies mojo's custom matplotlib theme to the correct folder.

    The function locates the user's matplotlib configuration folder, creates
    a `stylelib` folder and copies the theme to that folder (if it doesn't
    already exist). The first time the package is ever imported, the theme
    will be copied; on subsequent imports, the function will be skipped.

    Args:


    Returns:
        None: silent in both cases (copying the file, not copying the file)

    """

    # Defining paths
    mpl_cache_path = Path(mpl.get_configdir())
    mpl_theme_target_path = mpl_cache_path / "stylelib" / "mojo.mplstyle"

    if mpl_theme_target_path.is_file():
        pass
    else:
        # Create the stylelib path in case it doesn't yet exist
        mpl_theme_target_path.parent.mkdir(exist_ok=True)
        theme_loc = Path(__file__).parent / "resources" / "mojo.mplstyle"
        shutil.copy(theme_loc, mpl_theme_target_path)
