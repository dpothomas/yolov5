""" Module with constants used throughout the package """
from enum import Enum
import numpy as np


SUPERVISELY_CLASS_NAME_MAPPING = {
    "sperm": "sperm",
    "Low Conf Sperm": "sperm",
    "High Conf Sperm": "sperm",
}
ANNOTATION_CLASSES_TO_ID = {"sperm": 0}


class SplittingStrategy(str, Enum):
    random = "random"
    patient = "patient"
    load = "load"
    none = "none"


class ImageColors(str, Enum):
    bgr = "bgr"
    green = "green"
    gray = "gray"

DL_TEST_THRESHOLDS = np.arange(0.1, 0.8, step=0.1)

SPERM_COLOR = (255, 0, 0)
